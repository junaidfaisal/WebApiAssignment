﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebApi.Models
{
    public class UniversityModel
    {
        public string PK_ { get; set; }

        [Required(ErrorMessage = "Name is required")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Domain is required")]
        public string Domains { get; set; }

        [Required(ErrorMessage = "WebPages is required")]
        public string WebPages { get; set; }

        [Required(ErrorMessage = "Country is required")]
        public string Country { get; set; }

        [RegularExpression("^[a-zA-Z]{2}$", ErrorMessage = "AlphaTwoCode must be a two-letter alpha code")]
        public string AlphaTwoCode { get; set; }        

        [Required(ErrorMessage = "State/Province is required")]
        public string StateProvince { get; set; }
    }
}