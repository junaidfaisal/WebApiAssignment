﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using Newtonsoft.Json;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using WebApi.Models;
using System.Net.Http;

namespace WebApi.Controllers
{
    public class UniversityController : ApiController
    {
        SqlConnection CON;
        // GET api/<controller>
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        [System.Web.Http.Route("api/GetUniversityList")]
        public IHttpActionResult GetList(string CountryName="")
        {
            List<object> resultList = new List<object>();
            try
            {
                string conStr = ConfigurationManager.ConnectionStrings["DbString"].ConnectionString;

                using (CON = new SqlConnection(conStr))
                {
                    string query = "SELECT * FROM TRUNIVERSITY WHERE Country = '" + CountryName + "'";
                    SqlCommand command = new SqlCommand(query, CON);

                    CON.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        UniversityModel Obj = new UniversityModel
                        {
                            PK_ = reader["PK_"].ToString(),
                            Name = reader["name"].ToString(),
                            Domains = reader["domains"].ToString(),
                            WebPages = reader["web_pages"].ToString(),
                            Country = reader["country"].ToString(),
                            AlphaTwoCode = reader["alpha_two_code"].ToString(),
                            StateProvince = reader["state_province"].ToString()
                        };

                        resultList.Add(Obj);
                    }
                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                LOGFILE("Exception: " + ex.Message, "Error.txt");
            }
            return Ok(resultList);
        }

        [System.Web.Http.Route("api/GetUniversityByName")]
        public IHttpActionResult GetUniversityByName(string UniversityName = "")
        {
            List<object> resultList = new List<object>();
            try
            {
                string conStr = ConfigurationManager.ConnectionStrings["DbString"].ConnectionString;

                using (CON = new SqlConnection(conStr))
                {
                    string query = "SELECT * FROM TRUNIVERSITY WHERE name = '" + UniversityName + "'";
                    SqlCommand command = new SqlCommand(query, CON);

                    CON.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        UniversityModel Obj = new UniversityModel
                        {
                            PK_ = reader["PK_"].ToString(),
                            Name = reader["name"].ToString(),
                            Domains = reader["domains"].ToString(),
                            WebPages = reader["web_pages"].ToString(),
                            Country = reader["country"].ToString(),
                            AlphaTwoCode = reader["alpha_two_code"].ToString(),
                            StateProvince = reader["state_province"].ToString()
                        };

                        resultList.Add(Obj);
                    }
                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                LOGFILE("Exception: " + ex.Message, "Error.txt");
            }
            return Ok(resultList);
        }

        [System.Web.Http.Route("api/GetUniversityByID")]
        public IHttpActionResult GetUniversityByID(string UniversityID = "")
        {
            List<object> resultList = new List<object>();
            try
            {
                string conStr = ConfigurationManager.ConnectionStrings["DbString"].ConnectionString;

                using (CON = new SqlConnection(conStr))
                {
                    string query = "SELECT * FROM TRUNIVERSITY WHERE PK_ = '" + UniversityID + "'";
                    SqlCommand command = new SqlCommand(query, CON);

                    CON.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        UniversityModel Obj = new UniversityModel
                        {
                            PK_ = reader["PK_"].ToString(),
                            Name = reader["name"].ToString(),
                            Domains = reader["domains"].ToString(),
                            WebPages = reader["web_pages"].ToString(),
                            Country = reader["country"].ToString(),
                            AlphaTwoCode = reader["alpha_two_code"].ToString(),
                            StateProvince = reader["state_province"].ToString()
                        };

                        resultList.Add(Obj);
                    }
                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                LOGFILE("Exception: " + ex.Message, "Error.txt");
            }
            return Ok(resultList);
        }

        [HttpPost]
        [System.Web.Http.Route("api/SaveUniversity")]
        public HttpResponseMessage SaveUniversity([FromBody] UniversityModel MODEL)
        {

            if (!ModelState.IsValid)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
            }
            
            try
            {
                string conStr = ConfigurationManager.ConnectionStrings["DbString"].ConnectionString;
                CON = new SqlConnection(conStr);
                SqlCommand CMD = new SqlCommand();
                CMD.CommandType = CommandType.Text;
                CMD.CommandTimeout = 120;
                
                CMD.CommandText = "INSERT INTO TRUNIVERSITY (pk_,name,domains,web_pages,country,alpha_two_code,state_province) VALUES ((SELECT MAX(PK_)+1 FROM TRUNIVERSITY),@name,@domains,@web_pages,@country,@alpha_two_code,@state_province)";                
                CMD.Parameters.Add("@name", SqlDbType.NVarChar).Value = MODEL.Name;
                CMD.Parameters.Add("@domains", SqlDbType.NVarChar).Value = MODEL.Domains;
                CMD.Parameters.Add("@web_pages", SqlDbType.NVarChar).Value = MODEL.WebPages;
                CMD.Parameters.Add("@country", SqlDbType.NVarChar).Value = MODEL.Country;
                CMD.Parameters.Add("@alpha_two_code", SqlDbType.NVarChar).Value = MODEL.AlphaTwoCode;
                CMD.Parameters.Add("@state_province", SqlDbType.NVarChar).Value = MODEL.StateProvince;
                CON.Open();
                CMD.Connection = CON;
                int RESULT = CMD.ExecuteNonQuery();
                if (RESULT > 0)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, "University data saved successfully.");
                }
                return Request.CreateResponse(HttpStatusCode.InternalServerError, "An error occurred while saving university data.");
            }
            catch (Exception ex)
            {
                LOGFILE("Exception: " + ex.Message, "Error.txt");
                // Log the error
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, "An exception occurred while saving university data.");
            }
            finally
            {
                if (CON != null && CON.State == ConnectionState.Open)
                {
                    CON.Close();
                }
            }

        }

        [HttpPost]
        [System.Web.Http.Route("api/EditUniversity")]
        public HttpResponseMessage EditUniversity([FromBody] UniversityModel MODEL)
        {

            if (!ModelState.IsValid)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
            }

            try
            {
                string conStr = ConfigurationManager.ConnectionStrings["DbString"].ConnectionString;
                CON = new SqlConnection(conStr);
                SqlCommand CMD = new SqlCommand();
                CMD.CommandType = CommandType.Text;
                CMD.CommandTimeout = 120;

                CMD.CommandText = "UPDATE TRUNIVERSITY SET name=@name,domains=@domains,web_pages=@web_pages,state_province=@state_province where PK_=@pk and country=@country and alpha_two_code=@alpha_two_code";
                CMD.Parameters.Add("@pk", SqlDbType.NVarChar).Value = MODEL.PK_;
                CMD.Parameters.Add("@name", SqlDbType.NVarChar).Value = MODEL.Name;
                CMD.Parameters.Add("@domains", SqlDbType.NVarChar).Value = MODEL.Domains;
                CMD.Parameters.Add("@web_pages", SqlDbType.NVarChar).Value = MODEL.WebPages;
                CMD.Parameters.Add("@country", SqlDbType.NVarChar).Value = MODEL.Country;
                CMD.Parameters.Add("@alpha_two_code", SqlDbType.NVarChar).Value = MODEL.AlphaTwoCode;
                CMD.Parameters.Add("@state_province", SqlDbType.NVarChar).Value = MODEL.StateProvince;
                CON.Open();
                CMD.Connection = CON;
                int RESULT = CMD.ExecuteNonQuery();
                if (RESULT > 0)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, "University data saved successfully.");
                }
                return Request.CreateResponse(HttpStatusCode.InternalServerError, "An error occurred while saving university data.");
            }
            catch (Exception ex)
            {
                LOGFILE("Exception: " + ex.Message, "Error.txt");
                // Log the error
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, "An exception occurred while saving university data.");
            }
            finally
            {
                if (CON != null && CON.State == ConnectionState.Open)
                {
                    CON.Close();
                }
            }

        }
        public static void LOGFILE(string MSG, string filename = "logfile.txt")
        {
            //string PATH = HttpContext.Current.Server.MapPath("/") + @"logfile.txt";

            string PATH = HttpContext.Current.Server.MapPath("/") + filename;

            using (StreamWriter SW = (File.Exists(PATH)) ? File.AppendText(PATH) : File.CreateText(PATH))
            {
                SW.WriteLine(System.DateTime.Now.ToString() + " " + MSG);
                SW.Close();
            }
        }

        // GET api/<controller>/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<controller>
        public void Post([FromBody]string value)
        {
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}